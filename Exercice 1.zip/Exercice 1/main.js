var a = 4
var b = 4
var c = 3

if(a == b) {
    console.log("C'est égal")
}

if(c < b && a + c != 3) {
    console.log("ok")
} else {
    console.log("raté")
}

