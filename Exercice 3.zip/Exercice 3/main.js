let a = 7

for(let i = 0; i < a; i++){
    console.log("oklm")
}